    // Navigation Button Functionality
    document.getElementById('home-button').addEventListener('click', () => {
        navigateToPage('index.html');
    });

    document.getElementById('doctor-button').addEventListener('click', () => {
        navigateToPage('doctor.html');
    });

    document.getElementById('services-button').addEventListener('click', () => {
        navigateToPage('services.html');
    });

    document.getElementById('appointment-button').addEventListener('click', () => {
        navigateToPage('appointment.html');
    });

    // Reusable navigation function
    function navigateToPage(page) {
        if (pageExists(page)) {
            window.location.href = page;
        } else {
            alert(`The page "${page}" does not exist or is incorrectly linked.`);
        }
    }

    // Helper function to check if a page exists
    function pageExists(page) {
        // Create a new XMLHttpRequest to check the existence of the file
        const xhr = new XMLHttpRequest();
        xhr.open('HEAD', page, false);
        xhr.send();
        return xhr.status !== 404;
    }

    // Event listener for booking form submission
    document.getElementById('bookingForm').addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent the default form submission
        alert('Your appointment has been successfully booked!');
        this.reset(); // Optional: Reset the form fields after submission
    });

    // Event listener for rescheduling form submission
    document.getElementById('rescheduleForm').addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent the default form submission
        alert('Your appointment has been successfully rescheduled!');
        this.reset(); // Optional: Reset the form fields after submission
    });