<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['fullName'])) {
        // Booking Form Submission
        $fullName = $_POST['fullName'];
        $icNumber = $_POST['icNumber'];
        $dob = $_POST['dob'];
        $gender = $_POST['gender'];
        $phoneNumber = $_POST['phoneNumber'];
        $email = $_POST['email'];
        $appointmentDate = $_POST['appointmentDate'];
        $appointmentTime = $_POST['appointmentTime'];
        $doctor = $_POST['doctor'];

        // Process the data as needed (e.g., save to database)

        // Redirect back to the form with a success message
        echo "<script>alert('Your appointment has been successfully booked!'); window.location.href='index.html';</script>";
    } elseif (isset($_POST['appointmentId'])) {
        // Rescheduling Form Submission
        $appointmentId = $_POST['appointmentId'];
        $patientName = $_POST['patientName'];
        $currentDate = $_POST['currentDate'];
        $newDate = $_POST['newDate'];
        $newTime = $_POST['newTime'];
        $reason = $_POST['reason'];

        // Process the data as needed (e.g., update in database)

        // Redirect back to the form with a success message
        echo "<script>alert('Your appointment has been successfully rescheduled!'); window.location.href='index.html';</script>";
    } else {
        echo "<script>alert('Invalid form submission.'); window.location.href='index.html';</script>";
    }
}
?>
